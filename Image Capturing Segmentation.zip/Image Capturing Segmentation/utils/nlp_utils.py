# utils/nlp_utils.py
import nltk

def ensure_nltk():
    # Called once to download necessary tokenizers
    try:
        nltk.data.find('tokenizers/punkt')
    except LookupError:
        nltk.download('punkt')

    try:
        nltk.data.find('corpora/stopwords')
    except LookupError:
        nltk.download('stopwords')

if __name__ == "__main__":
    ensure_nltk()