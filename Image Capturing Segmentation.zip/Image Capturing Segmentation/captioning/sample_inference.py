# captioning/sample_inference.py
import sys
import numpy as np
from captioning.extract_features import build_feature_extractor, extract_feature_from_path
from captioning.model import CaptioningModel, SimpleTokenizer

def demo(image_path):
    ext = build_feature_extractor()
    feat = extract_feature_from_path(ext, image_path)
    # load a tiny dummy tokenizer for demo
    # in practice load tokenizer from training (json or pickle)
    dummy_index = {"startseq":1, "a":2, "man":3, "with":4, "dog":5, "endseq":6}
    tokenizer = SimpleTokenizer(dummy_index)
    model = CaptioningModel(vocab_size=100, max_length=20)
    # NOTE: model weights are random if you don't train. This returns gibberish until trained.
    caption = model.generate_caption(feat, tokenizer)
    print("Caption:", caption)

if __name__ == "__main__":
    demo(sys.argv[1])