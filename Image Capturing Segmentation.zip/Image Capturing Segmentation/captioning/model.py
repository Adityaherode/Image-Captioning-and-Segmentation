# captioning/model.py
import tensorflow as tf
from tensorflow.keras import layers, Model
from tensorflow.keras.applications.inception_v3 import InceptionV3, preprocess_input
from tensorflow.keras.preprocessing.sequence import pad_sequences
import numpy as np
import os
import json

class CaptioningModel:
    def __init__(self, vocab_size=5000, max_length=34, embedding_dim=256, units=512):
        self.vocab_size = vocab_size
        self.max_length = max_length
        self.embedding_dim = embedding_dim
        self.units = units
        self.build_model()

    def build_model(self):
        # Encoder (precomputed features -> dense projection)
        features_input = layers.Input(shape=(2048,), name="image_features")
        x = layers.Dense(self.embedding_dim, activation="relu")(features_input)
        x = layers.Reshape((1, self.embedding_dim))(x)

        # Decoder (LSTM)
        seq_input = layers.Input(shape=(self.max_length,), name="seq_input")
        seq_emb = layers.Embedding(self.vocab_size, self.embedding_dim, mask_zero=True)(seq_input)

        merged = layers.Concatenate(axis=1)([x, seq_emb])
        lstm_out = layers.LSTM(self.units, return_sequences=True)(merged)
        out = layers.TimeDistributed(layers.Dense(self.vocab_size, activation="softmax"))(lstm_out)

        self.model = Model([features_input, seq_input], out)
        self.model.compile(optimizer="adam", loss="sparse_categorical_crossentropy")
    
    def summary(self):
        self.model.summary()

    def save(self, path):
        self.model.save(path)

    def load(self, path):
        self.model = tf.keras.models.load_model(path)

    # Simple greedy inference using a tokenizer mapping
    def generate_caption(self, feature_vector, tokenizer, start_token="startseq", end_token="endseq"):
        inv_map = {v:k for k,v in tokenizer.word_index.items()}
        seq = [tokenizer.word_index.get(start_token, 1)]
        for i in range(self.max_length):
            padded = pad_sequences([seq], maxlen=self.max_length, padding='post')
            preds = self.model.predict([feature_vector.reshape(1,-1), padded])
            # take the token at position len(seq) (since we have leading feature token)
            pred_prob = preds[0, len(seq), :]
            next_idx = np.argmax(pred_prob)
            word = inv_map.get(next_idx, None)
            if word is None:
                break
            seq.append(next_idx)
            if word == end_token:
                break
        # convert seq back to words
        words = []
        for idx in seq[1:]:  # skip start
            w = inv_map.get(idx, "")
            if w in (start_token, end_token, ""):
                continue
            words.append(w)
        return " ".join(words)

# Minimal tokenizer example wrapper
class SimpleTokenizer:
    def __init__(self, word_index):
        self.word_index = word_index

if __name__ == "__main__":
    # quick smoke test: build model and print summary
    m = CaptioningModel()
    m.summary()