# captioning/extract_features.py
import tensorflow as tf
from tensorflow.keras.applications.inception_v3 import InceptionV3, preprocess_input
from tensorflow.keras.preprocessing import image
import numpy as np
import os
from tqdm import tqdm

def build_feature_extractor():
    base = InceptionV3(weights="imagenet", include_top=False, pooling='avg')
    return base

def extract_feature_from_path(model, img_path, target_size=(299,299)):
    img = image.load_img(img_path, target_size=target_size)
    x = image.img_to_array(img)
    x = np.expand_dims(x, axis=0)
    x = preprocess_input(x)
    feat = model.predict(x)
    return feat.squeeze()

def extract_features_for_folder(img_folder, out_folder="features", force=False):
    os.makedirs(out_folder, exist_ok=True)
    model = build_feature_extractor()
    for fname in tqdm(os.listdir(img_folder)):
        if not fname.lower().endswith((".jpg", ".jpeg", ".png")):
            continue
        out_file = os.path.join(out_folder, fname + ".npy")
        if os.path.exists(out_file) and not force:
            continue
        feat = extract_feature_from_path(model, os.path.join(img_folder, fname))
        np.save(out_file, feat)

if __name__ == "__main__":
    import argparse
    p = argparse.ArgumentParser()
    p.add_argument("--images", required=True, help="Folder with images")
    p.add_argument("--out", default="features")
    args = p.parse_args()
    extract_features_for_folder(args.images, args.out)