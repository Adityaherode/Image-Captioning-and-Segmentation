# segmentation/simple_seg.py
import cv2
import numpy as np

def grabcut_segmentation(img_path, iter_count=5):
    img = cv2.imread(img_path)
    mask = np.zeros(img.shape[:2], np.uint8)
    rect = (10,10, img.shape[1]-20, img.shape[0]-20)  # rough init rect
    bgdModel = np.zeros((1,65), np.float64)
    fgdModel = np.zeros((1,65), np.float64)
    cv2.grabCut(img, mask, rect, bgdModel, fgdModel, iter_count, cv2.GC_INIT_WITH_RECT)
    # mask=0 or 2 are background, 1 or 3 foreground
    mask2 = np.where((mask==2)|(mask==0), 0, 1).astype('uint8')
    img_cut = img * mask2[:, :, np.newaxis]
    return img_cut, mask2

if __name__ == "__main__":
    import sys
    out, mask = grabcut_segmentation(sys.argv[1])
    cv2.imwrite("grabcut_result.png", out)
    print("Saved grabcut_result.png")
